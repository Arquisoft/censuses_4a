package es.uniovi.asw;

public class Calculator {

	Integer add(Integer x, Integer y) {
		return x + y;
	}
	
}
