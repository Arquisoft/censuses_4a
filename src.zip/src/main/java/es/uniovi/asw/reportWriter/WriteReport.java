package es.uniovi.asw.reportWriter;

public interface WriteReport {
	
	public void report(String data);

}
