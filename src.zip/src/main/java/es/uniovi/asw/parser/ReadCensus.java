package es.uniovi.asw.parser;

public interface ReadCensus {
	
	public void readCensus(String[] args);

}
