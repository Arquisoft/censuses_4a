package es.uniovi.asw.parser;

import es.uniovi.asw.voters.Voter;

public interface Generator {

	public void generate(Voter voter);
}
