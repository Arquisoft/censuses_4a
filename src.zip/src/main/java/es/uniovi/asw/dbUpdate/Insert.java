package es.uniovi.asw.dbUpdate;

import java.util.List;

import es.uniovi.asw.voters.Voter;

public interface Insert {
	
	public void insert(List<Voter> voters); 

}
